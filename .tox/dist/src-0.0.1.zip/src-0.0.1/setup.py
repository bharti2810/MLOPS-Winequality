from setuptools import setup, find_packages


setup(
    name = "src",
    version = "0.0.1" ,# it is first version
    description = "its a wine Q package",
    author = "bharti2810",
    packages = find_packages(),
    license = "MIT"
)